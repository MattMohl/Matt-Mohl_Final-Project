The Mana Pool
A deck building community

All content, cards, set symbols and names are property of Wizards of the Coast and I am not affiliated with Wizards in any way. 

Any iconography (not to be confused with set symbols) are created by various The Noun Project contributors, including the following.

	-Person 10580
	Designed by Alex Fuller
	Chicago, Illinois, US 2013

	-Lock 10982
	Designed by Alexandra Coscovelnita
	Otopeni, RO 2013

	-Flash Cards 4767
	Designed by Rohan Gupta
	Bangalore, Karnataka, IN 2012

	-Magazine 10798
	Designed by Nicholas Menghini
	Chicago, Illinois, US 2013

	-Magnifying Glass 4585
	Designed by SimpleScott
	Chicago, Illinois, US 2012

	-Arrow 15432
	Designed by Alex S. Lakas
	San Francisco, California, US 2013

	-Check Mark 15426
	Designed by Alex S. Lakas
	San Francisco, California, US 2013

	-Equilizer 29229
	Designed by Stephan Langenegger
	Lucerne, Kanton Luzern, CH 2014

	-Sun 7551
	Designed by Benni
	DE 2012

	-Drop 20541
	Designed by Eric Bergholz
	Dessau, DE 2013

	-Skull 29715
	Designed by Vivian Ziereisen
	Basel-Stadt, Basel, CH 2014

	-Fire 17732
	Designed by Diego Naive
	João Pessoa, Paraiba, BR 2013

	-Tree 7612
	Designed by Humberto Pornaro
	São Paulo Brazil, BR 2012

	-Question 15356
	Designed by SuperAtic LABS
	Surry Hills, New South Wales, AU 2012

	-Menu 22191
	Designed by JD
	2013